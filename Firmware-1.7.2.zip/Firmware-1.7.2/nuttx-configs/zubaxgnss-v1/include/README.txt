This directory contains header files unique to the
Zubax GNSS board

https://github.com/Zubax/zubax_gnss
