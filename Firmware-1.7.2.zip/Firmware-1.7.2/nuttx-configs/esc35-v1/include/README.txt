This directory contains header files unique to the
AUAV ESC35 V1.0 board using STM32F303CC
