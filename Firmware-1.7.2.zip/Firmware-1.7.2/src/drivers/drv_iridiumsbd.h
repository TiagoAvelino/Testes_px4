#pragma once

#include <stdint.h>
#include <sys/ioctl.h>

#include "board_config.h"

#define IRIDIUMSBD_DEVICE_PATH	"/dev/iridium"
