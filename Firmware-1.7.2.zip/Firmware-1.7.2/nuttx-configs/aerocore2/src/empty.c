/*
 * There are no source files here, but libboard.a can't be empty, so
 * we have this empty source file to keep it company.
 */
